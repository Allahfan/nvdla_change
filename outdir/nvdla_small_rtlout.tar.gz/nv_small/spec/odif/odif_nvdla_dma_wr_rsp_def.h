#if !defined(_nvdla_dma_wr_rsp_IFACE)
#define _nvdla_dma_wr_rsp_IFACE

#define FLOW_nvdla_dma_wr_rsp none

#define SIG_nvdla_dma_wr_rsp_complete_WIDTH 1
#define SIG_nvdla_dma_wr_rsp_complete_FIELD 0:0

#endif // !defined(_nvdla_dma_wr_rsp_IFACE)