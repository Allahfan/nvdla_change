#if !defined(_sdp2pdp_if_IFACE)
#define _sdp2pdp_if_IFACE

#define FLOW_sdp2pdp_if valid_ready

#define SIG_sdp2pdp_if_pd_WIDTH 8
#define SIG_sdp2pdp_if_pd_FIELD 7:0

#endif // !defined(_sdp2pdp_if_IFACE)