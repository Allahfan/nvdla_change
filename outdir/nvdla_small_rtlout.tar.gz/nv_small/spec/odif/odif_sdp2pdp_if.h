#if !defined(_sdp2pdp_if_iface_H_)
#define _sdp2pdp_if_iface_H_

#include <stdint.h>
typedef struct sdp2pdp_if_s {
    sc_int<8> pd ;
} sdp2pdp_if_t;

#endif // !defined(_sdp2pdp_if_iface_H_)
